const Blog=require('../models/Blog');

const getAllBlogs=async(req,res,next)=>{
    let blogs;
    try{
        blogs=await Blog.find({});
    }catch(err){
        return console.log(err);
    }
    if(!blogs){
        return res.status(404).json({message:'Blog not found'});
    }
    return res.status(200).json({blogs});
}
const addBlog=async(req,res,next)=>{
    // let existingUser;
    // try{
    //     existingUser=await User.findById(user);
    // }catch(err){
    //     return consol.log(err);
    // }
    // if(!existingUser){
    //     return res.status(400).json({message:'unalbe to find by User ID'})
    // }

    const {title,description,image,user}=req.query;
    const blog=new Blog({
        title:title,
        description:description,
        image:image,
        user:user,
    });
    try{
    //    const session=await Mongoose.startSession();
    //    session.startTransaction();
       await blog.save();
    //    existingUser.blogs.push(blog);
    //    await existingUser.save({session});
    //    await session.commitTransaction();
    }catch(err){
        console.log(err);
        return res.status(500).json({message:err});
    }
    return res.status(200).json({blog});
}

const updateBlog=async(req,res,next)=>{
    const {title,description}=req.query;
   const blogId=req.params.id;
   let blog;
   try{
    blog=await Blog.findByIdAndUpdate(blogId,{
      title:title,
      description:description,
   })
}catch(err){
    return console.log(err);
}
if(!blog){
    return res.status(500).json({message:'unable to update blog'});
}
return res.status(200).json({blog})
}

const getById=async(req,res,next)=>{
    const id=req.params.id;
    let blog;
    try{
       blog=await Blog.findById(id);
    }catch(err){
        return console.log(err);
    }
    if(!blog){
        return res.status(404).json({message:'no blog found'});
    }
    return res.status(200).json({blog});
}


const deleteBlog=async(req,res,next)=>{
    const id=req.params.id;

    let blog;
    try{
        blog=await Blog.findByIdAndRemove(id);
    }catch(err){
        console.log(err);
    }
    if(!blog){
        return res.status(400).json({message:'unable to delete'});
    }
    return res.status(200).json({message:'succesfully deleted'});
}
module.exports={
    getAllBlogs,addBlog,updateBlog,getById,deleteBlog
}
