const express=require('express');
const mongoose=require('mongoose');
const router=require('./routes/user-routes');
const blogRouter=require('./routes/blog-routes');
const app=express();
const port = 5000;

app.use(express.json());
app.use('/api/user',router);
app.use('/api/blog',blogRouter);

mongoose.connect('mongodb://127.0.0.1:27017/REST_API_YOUTUBE')
.then(()=>{
    console.log(`database  connected on ${port}`)
})
.catch((err)=>{
    console.log(err);
})



app.listen(port,()=>{
    console.log(`Server is running on port ${port}`);
})
